// Ce composant ne sert qu'à l'affichage d'une "vignette" dans la grille
function PokemonCard({ pokemon, onSelect }) {
    
    // ASTUCE : Si App.jsx a fait le "Super-Fetch", pokemon.sprites existe déjà !
    // Sinon, on garde l'ancienne méthode de calcul via l'URL (Fallback)
    
    let imageUrl;
    
    if (pokemon.sprites && pokemon.sprites.front_default) {
        // Cas 1 : Données complètes disponibles (Optimisé)
        imageUrl = pokemon.sprites.front_default;
    } else {
        // Cas 2 : Seulement nom + url disponibles (Ancienne méthode)
        const urlParts = pokemon.url.split('/');
        // .filter(Boolean).pop() est plus robuste pour trouver l'ID même s'il y a un "/" à la fin
        const pokemonId = urlParts.filter(Boolean).pop(); 
        imageUrl = `https://raw.githubusercontent.com/PokeAPI/sprites/master/sprites/pokemon/${pokemonId}.png`;
    }

    return (
        <div style={{
            border: '1px solid #ccc',
            padding: '10px',
            borderRadius: '8px',
            textAlign: 'center',
            backgroundColor: '#020202',
            transition: 'transform 0.2s' // Petite animation douce (optionnel)
        }}>
            {/* L'image de la vignette */}
            <img
                src={imageUrl}
                alt={pokemon.name}
                style={{ width: '96px', height: '96px' }}
                // Si l'image ne charge pas, on évite le carré brisé (optionnel)
                onError={(e) => { e.target.onerror = null; e.target.src = 'https://via.placeholder.com/96' }}
            />
            
            {/* Nom du Pokémon (Première lettre majuscule via CSS) */}
            <h3 style={{ textTransform: 'capitalize', color: 'white', margin: '10px 0' }}>
                {pokemon.name}
            </h3>

            {/* Bouton qui déclenche la sélection dans App.jsx */}
            <button
                onClick={() => onSelect(pokemon)}
                style={{ 
                    cursor: 'pointer', 
                    padding: '5px 10px',
                    borderRadius: '4px',
                    border: 'none',
                    backgroundColor: '#8a8a8a', // Jaune Pokémon
                    color: '#ffffff', // Bleu Pokémon
                    fontWeight: 'bold'
                }} 
            > 
                Voir détails 
            </button>
        </div>
    );
}

export default PokemonCard;