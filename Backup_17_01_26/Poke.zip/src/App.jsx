import { useState, useEffect } from 'react';
import './App.css'; // Import des styles globaux
import PokemonCard from './PokemonCard'; // Composant pour afficher une carte individuelle
import PokemonDetail from './PokemonDetail'; // Composant pour afficher la vue détaillée

function App() {
  // --- ÉTATS (MÉMOIRE DU COMPOSANT) ---

  // Stocke la liste complète des Pokémon avec TOUS leurs détails (Poids, types, etc.)
  const [pokemonList, setPokemonList] = useState([]);

  // Stocke le Pokémon sur lequel l'utilisateur a cliqué (null = aucun sélectionné)
  const [selectedPokemon, setSelectedPokemon] = useState(null);

  // Indique si l'application est en train de charger des données (Vrai au démarrage)
  const [isLoading, setIsLoading] = useState(true);

  // Stocke un message d'erreur si le réseau échoue (null = tout va bien)
  const [error, setError] = useState(null);

  // Stocke le texte tapé dans la barre de recherche.
  // Initialisé avec le localStorage pour se souvenir de la dernière recherche.
  const [searchTerm, setSearchTerm] = useState(localStorage.getItem('last_search') || "");

  // Indique si on doit afficher seulement les favoris ou toute la liste
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);

  // NOUVEAU : Stocke le critère de tri choisi ('id', 'name', 'weight', 'height')
  const [sortCriteria, setSortCriteria] = useState('id');

  // Initialisation des favoris depuis le localStorage (mémoire du navigateur)
  // On utilise une fonction () => ... pour que ce calcul lourd ne se fasse qu'une seule fois.
  const [favorites, setFavorites] = useState(() => {
    const saved = localStorage.getItem('pokedex_favorites');
    return saved ? JSON.parse(saved) : []; // Si on a des données on les parse, sinon tableau vide
  });

  // --- LOGIQUE MÉTIER ---

  // Fonction pour ajouter ou retirer un favori (Mode "Bascule" / Toggle)
  const saveFavorite = (pokemon) => {
    // On vérifie si le Pokémon est DÉJÀ dans la liste
    const isAlreadyFavorite = favorites.some(fav => fav.name === pokemon.name);
    let updatedFavorites;

    if (isAlreadyFavorite) {
      // Si oui, on garde tous ceux qui NE SONT PAS ce pokemon (Suppression)
      updatedFavorites = favorites.filter(fav => fav.name !== pokemon.name);
    } else {
      // Si non, on crée un nouveau tableau avec les anciens + le nouveau (Ajout)
      updatedFavorites = [...favorites, pokemon];
    }

    // Mise à jour de l'état et sauvegarde durable dans le navigateur
    setFavorites(updatedFavorites);
    localStorage.setItem('pokedex_favorites', JSON.stringify(updatedFavorites));
  };

  // NOUVEAU FETCH : Récupération des données COMPLÈTES (Le "Super-Fetch")
  const fetchPokemons = async () => {
    try {
      setIsLoading(true); // On affiche le loader
      setError(null);     // On efface les anciennes erreurs

      // 1. On récupère la liste simple (151 noms + urls)
      const response = await fetch('https://pokeapi.co/api/v2/pokemon?limit=1003');
      if (!response.ok) throw new Error("Erreur lors de la récupération de la liste");
      const data = await response.json();

      // 2. Pour chaque Pokémon, on lance un fetch vers son URL spécifique pour avoir son poids/taille/types
      // detailedPromises est un tableau de "promesses" (requêtes en attente)
      const detailedPromises = data.results.map(async (pokemon) => {
        const detailResponse = await fetch(pokemon.url);
        return detailResponse.json(); // On récupère l'objet complet
      });

      // 3. Promise.all attend que les 151 requêtes soient finies !
      const detailedList = await Promise.all(detailedPromises);

      // 4. On stocke la liste détaillée
      setPokemonList(detailedList);

    } catch (error) {
      console.error(error);
      setError("Impossible de charger les Pokémon. Vérifiez votre connexion.");
    } finally {
      setIsLoading(false); // Quoi qu'il arrive, on enlève le loader à la fin
    }
  };

  // --- EFFETS DE BORD (CYCLES DE VIE) ---

  // Au démarrage de l'app (tableau [] vide), on lance le fetch
  useEffect(() => {
    fetchPokemons();
  }, []);

  // À chaque fois que searchTerm change, on sauvegarde dans le localStorage
  useEffect(() => {
    localStorage.setItem('last_search', searchTerm);
  }, [searchTerm]);


  // --- LOGIQUE DE TRI ET FILTRAGE ---

  // 1. Choix de la source : Tout le monde OU juste les favoris
  const listSource = showFavoritesOnly ? favorites : pokemonList;

  // 2. Application du FILTRE de recherche sur la source choisie
  const searchedList = listSource.filter((pokemon) =>
    pokemon.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  // 3. Application du TRI sur la liste déjà filtrée
  // On utilise [...searchedList] pour créer une copie et ne pas modifier l'original
  const filteredPokemons = [...searchedList].sort((a, b) => {
    // Sécurité : Optional Chaining (?.) pour éviter les crashs si les données ne sont pas chargées
    switch (sortCriteria) {
      case 'weight':
        return (b.weight || 0) - (a.weight || 0); // Décroissant (Plus lourd en premier)
      case 'height':
        return (b.height || 0) - (a.height || 0); // Décroissant (Plus grand en premier)
      case 'name':
        return a.name.localeCompare(b.name);      // Alphabétique
      case 'type':
        const typeA = a.types?.[0]?.type?.name || "";
        const typeB = b.types?.[0]?.type?.name || "";
        return typeA.localeCompare(typeB);
      case 'id':
      default:
        return (a.id || 0) - (b.id || 0);         // Par défaut : Ordre numérique
    }
  });
  // --- RENDU VISUEL (JSX) ---
  return (
    <div className="App" style={{ position: 'relative' }}>
      
      {/* En-tête */}
      <h1 style={{ textAlign: 'center', color: '#ccc' }}>Mon Pokédex</h1>
      
      {/* Si un Pokémon est sélectionné, on affiche sa fiche détail */}
      {selectedPokemon ? (
        <PokemonDetail
          pokemon={selectedPokemon}
          onBack={() => setSelectedPokemon(null)} // Fonction pour revenir en arrière
          onToggleFavorite={saveFavorite}         // Fonction pour gérer le favori
          isFavorite={favorites.some(f => f.name === selectedPokemon.name)} // Booléen : est-il favori ?
        />
      ) : (
        <>
          {/* Bouton pour basculer l'affichage des favoris */}
          <button
            onClick={() => setShowFavoritesOnly(!showFavoritesOnly)}
            style={{
              position: 'absolute',
              top: '20px', right: '20px',
              padding: '10px 15px', borderRadius: '8px',
              backgroundColor: showFavoritesOnly ? '#ff4d4d' : '#333',
              color: 'white', border: '1px solid #555',
              cursor: 'pointer', fontWeight: 'bold', zIndex: 100
            }}
          >
            {showFavoritesOnly ? '🏠 Voir Tout' : '❤️ Mes Favoris'}
          </button>
          
          {/* Sinon, on affiche la liste (Dashboard) */}
          {/* Gestion d'erreur */}
          {error && <p style={{ color: 'red', textAlign: 'center' }}>{error}</p>}
          
          {/* Loader pendant le chargement initial */}
          {isLoading ? (
            <div className="loader"></div>
          ) : (
            <>
              {/* ZONE DE CONTRÔLE : Recherche + Tri */}
              <div style={{ display: 'flex', flexDirection: 'column', alignItems: 'center', gap: '15px', marginBottom: '30px' }}>
                
                {/* Barre de recherche */}
                <input
                  style={{
                    padding: '15px', borderRadius: '8px', textAlign: 'center',
                    backgroundColor: '#020202', color: 'white', border: '1px solid #ccc', width: '300px'
                  }}
                  type="text"
                  placeholder="Rechercher..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                />

                {/* NOUVEAU : Menu déroulant de tri */}
                <div style={{ color: 'white' }}>
                  <label htmlFor="sort-select" style={{ marginRight: '10px' }}>Trier par : </label>
                  <select 
                    id="sort-select"
                    value={sortCriteria} 
                    onChange={(e) => setSortCriteria(e.target.value)}
                    style={{ padding: '8px', borderRadius: '5px' }}
                  >
                    <option value="id">Numéro (Défaut)</option>
                    <option value="name">Nom (A-Z)</option>
                    <option value="weight">Poids (plus lourd)</option>
                    <option value="height">Taille (plus grand)</option>
                    <option value="type">Type</option>
                  </select>
                </div>

              </div>

              {/* GRILLE DES POKÉMONS */}
              <div className="pokemon-list" style={{
                display: 'grid',
                gridTemplateColumns: 'repeat(auto-fill, minmax(150px, 1fr))', // Responsive automatique
                gap: '10px', minHeight: '50vh'
              }}>
                {filteredPokemons.map((poke) => (
                  <PokemonCard
                    key={poke.name} // Clé unique obligatoire pour React (Performance)
                    pokemon={poke}
                    onSelect={setSelectedPokemon}
                  />
                ))}

                {/* Message si aucun résultat trouvé */}
                {filteredPokemons.length === 0 && (
                  <p style={{ gridColumn: '1/-1', textAlign: 'center', color: '#888' }}>
                    {showFavoritesOnly ? "Aucun favori trouvé." : "Aucun Pokémon ne correspond."}
                  </p>
                )}
              </div>
            </>
          )}
        </>
      )}
    </div>
  );
}

export default App;