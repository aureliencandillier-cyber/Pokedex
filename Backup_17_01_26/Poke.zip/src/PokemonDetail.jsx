import { useState, useEffect } from 'react';

// Le composant reçoit 4 "props" (outils) du parent App.jsx
function PokemonDetail({ pokemon, onBack, onToggleFavorite, isFavorite }) {
  
  // État local pour stocker les détails précis du Pokémon
  const [details, setDetails] = useState(null);
  
  // État de chargement local (juste pour cette fiche)
  const [loading, setLoading] = useState(true);

  // useEffect se déclenche à chaque fois que la prop 'pokemon' change
  useEffect(() => {
    const fetchDetails = async () => {
      try {
        setLoading(true); // On commence le chargement
        
        // On récupère les données via l'URL fournie dans l'objet pokemon
        const response = await fetch(pokemon.url || `https://pokeapi.co/api/v2/pokemon/${pokemon.id}`);
        const data = await response.json();
        
        setDetails(data); // On sauvegarde les données reçues
      } catch (error) {
        console.error("Erreur détails:", error);
      } finally {
        setLoading(false); // On arrête le chargement (succès ou échec)
      }
    };
    fetchDetails();
  }, [pokemon]); // [pokemon] = dépendance. Si le pokemon change, on relance l'effet.

  // Si ça charge, on affiche un texte simple
  if (loading) return <p style={{ textAlign: 'center' }}>Chargement des détails...</p>;
  
  // Si le chargement a échoué (details est vide), on affiche une erreur
  if (!details) return <p style={{ textAlign: 'center' }}>Erreur : impossible de charger les données.</p>;

  return (
    // Conteneur principal
    <div style={{ textAlign: 'center', padding: '20px', position: 'relative', minHeight: '80vh' }}>
      
      {/* Bouton retour qui appelle la fonction du parent pour "désélectionner" */}
      <button onClick={onBack} style={{ cursor: 'pointer', padding: '10px' }}>← Retour</button>

      {/* Carte d'informations */}
      <div style={{ marginTop: '20px', border: '1px solid #ddd', borderRadius: '20px', padding: '20px', backgroundColor: '#000000' }}>
        
        {/* Image du Pokémon. 
            L'opérateur ?. (Optional Chaining) évite le crash si 'sprites' n'existe pas.
            L'opérateur || fournit une image de remplacement si la première est manquante. */}
        <img
          src={details.sprites?.front_default || 'https://via.placeholder.com/150'}
          alt={details.name}
          style={{ width: '150px' }}
        />

        <h2 style={{ textTransform: 'capitalize', color: '#ffffff' }}>{details.name}</h2>
        
        {/* Statistiques physiques */}
        <div style={{ display: 'flex', justifyContent: 'center', gap: '20px', color: '#ffffff' }}>
          {/* L'API donne le poids en hectogrammes, on divise par 10 pour avoir des KG */}
          <p><strong>Poids :</strong> {details.weight / 10} kg</p>
          <p><strong>Taille :</strong> {details.height / 10} m</p>
        </div>

        {/* Liste des types */}
        <div style={{ marginTop: '10px' }}>
          <strong style={{ color: '#ffffff' }}>Types : </strong>
          {/* On boucle sur le tableau des types */}
          {details.types.map((t) => (
            <span
              key={t.type.name} // Clé unique obligatoire
              style={{
                margin: '0 5px',
                padding: '5px 12px',
                background: '#020202',
                color: '#ffffff', // Contraste important pour la lisibilité
                borderRadius: '10px',
                fontSize: '0.9em',
                display: 'inline-block'
              }}
            >
              {t.type.name}
            </span>
          ))}
        </div>
      </div>

      {/* BOUTON FAVORIS (Fixe en bas à droite) */}
      <button
        onClick={() => onToggleFavorite(pokemon)} // Appelle la fonction saveFavorite de App.jsx
        style={{
          position: 'fixed',
          bottom: '20px', right: '20px',
          padding: '12px 20px',
          borderRadius: '30px', border: 'none', cursor: 'pointer',
          // Changement de couleur dynamique selon l'état isFavorite
          backgroundColor: isFavorite ? '#ff4d4d' : '#4CAF50',
          color: 'white', fontWeight: 'bold',
          boxShadow: '0 4px 10px rgba(0,0,0,0.3)',
          zIndex: 9999 // S'assure d'être au-dessus de tout le reste
        }}
      >
        {isFavorite ? '❤️ Retirer des favoris' : '🤍 Ajouter aux favoris'}
      </button>
    </div>
  );
}

export default PokemonDetail;